(function init(){
    if(localStorage.getItem('matchStarts')){
        document.querySelector('#versus').classList.add('hidden')
        document.querySelector('.stat-wrap').classList.remove('hidden')
        cmd1 = JSON.parse(localStorage.getItem('statCmd1'))
        cmd2 = JSON.parse(localStorage.getItem('statCmd2'))

        document.querySelector('.foul .cmd-1').innerHTML = cmd1.foul;
        document.querySelector('.stat-result .cmd-1').innerHTML = cmd1.title;
        document.querySelector('.score .score-1').innerHTML = Object.keys(cmd1.goal).length;
        document.querySelector('label[for="cmd-1-tab"]').innerHTML = cmd1.title
        insertPlayersToOptions(cmd1.player, '.selector-cmd-1 select')
        
        document.querySelector('.foul .cmd-2').innerHTML = cmd2.foul;
        document.querySelector('.stat-result .cmd-2').innerHTML = cmd2.title;
        document.querySelector('.score .score-2').innerHTML = Object.keys(cmd2.goal).length;
        document.querySelector('label[for="cmd-2-tab"]').innerHTML = cmd2.title
        insertPlayersToOptions(cmd2.player, '.selector-cmd-2 select')


    }
})();

function createElement(elementName, value, classList) {
    classList = classList || "";
    var el = document.createElement(elementName);
    el.innerHTML = value;
    el.className = classList
    return el;
}

function createFormElement(elementName, attr, classList) {
    classList = classList || "";
    var el = document.createElement(elementName);
    el.className = classList
    if(attr){
        if(Object.keys(attr).length>0) {
            for(var i in attr) {
                el.setAttribute(i, attr[i])
            }
        }
    }
    return el;
}

var cmd1 = document.querySelector('#cmd-1');
var cmd2 = document.querySelector('#cmd-2');

teams.forEach(el=>{
    cmd1.append(createElement('option', el.title));
    cmd2.append(createElement('option', el.title));
})

function matchStart(e) {
    document.querySelector('#versus')
    .addEventListener('submit', e => {
        e.preventDefault()
        e.target.classList.add('hidden')
        document.querySelector('.stat-wrap').classList.remove('hidden')
    })

    initStat()
}



function initStat(){
    localStorage.setItem('matchStarts', new Date().valueOf()); 
    localStorage.setItem('pause', 0);
    localStorage.setItem('pauseStatus', false); 
    var statCmd1 = {goal: {},red: {},yellow: {},foul: 0, auto: {}};
    var statCmd2 = {goal: {},red: {},yellow: {},foul: 0, auto: {}};
    document.querySelector('.stat-result .cmd-1').innerHTML = cmd1.value;
    document.querySelector('.stat-result .cmd-2').innerHTML = cmd2.value;
    teams.forEach(el=>{
        switch (el.title) {
            case cmd1.value:
                document.querySelector('label[for="cmd-1-tab"]').innerHTML = cmd1.value
                statCmd1.title = cmd1.value;
                statCmd1.player = el.players;
                insertPlayersToOptions(el.players, '.selector-cmd-1 select')
                break;
            case cmd2.value:
                document.querySelector('label[for="cmd-2-tab"]').innerHTML = cmd2.value
                statCmd2.title = cmd2.value;
                statCmd2.player = el.players;
                insertPlayersToOptions(el.players, '.selector-cmd-2 select')
                break;
        }
    })
    localStorage.setItem('statCmd1', JSON.stringify(statCmd1))
    localStorage.setItem('statCmd2', JSON.stringify(statCmd2))
}

function insertPlayersToOptions(players, to) {
    players.forEach(option=>{
        document.querySelector(to)
            .insertAdjacentElement('beforeend', createElement('option', option))
    });
}

function getMatchSec(){
    return (new Date().valueOf() - localStorage.getItem('matchStarts') ) / 1000
}

pause = document.querySelector('.pause');
pause.addEventListener('change', e=>{
    var pauseStatus = Boolean(localStorage.getItem('pauseStatus'));
    localStorage.setItem('pauseStatus', !pauseStatus);
    console.log()
})

function timer(){
    return setInterval(()=>{
        localStorage.setItem('pause', +localStorage.getItem('pause') + 1);
    }, 1000)
}

function addAction(){
    var forms = document.querySelectorAll('.modal-content .selected form');
    var action = {};
    var hasInvadil = false;
    forms.forEach((value, key) => {
        if(value.checkValidity()) {
            action[key] = Object.fromEntries(new FormData(value))
            value.parentElement.remove();
        } else {
            value.querySelector('.submit-form').click();
            
        }
    });
    console.log(action)
    
}
document.querySelector('.btn-select').addEventListener('click', e=>{
    addAction();
    // modalToggle();
})
